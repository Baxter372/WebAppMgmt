// ...IMPORTS...
import React, { useState, useEffect, useRef } from 'react';
import './App.css';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  useDroppable,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  useSortable,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, CartesianGrid } from 'recharts';

// ...MODAL COMPONENT...
const Modal: React.FC<{ onClose: () => void, children: React.ReactNode }> = ({ onClose, children }) => (
  <div className="modal-backdrop" onClick={onClose}>
    <div className="modal" onClick={e => e.stopPropagation()}>
      <button className="modal-close" onClick={onClose} title="Close">&times;</button>
      {children}
    </div>
  </div>
);

// ...TYPES...
type Tile = {
  id: number;
  name: string;
  description: string;
  link: string;
  category: string;
  subcategory?: string;
  logo: string;
  appType?: 'web' | 'local' | 'protocol';
  localPath?: string;
  paidSubscription?: boolean;
  paymentFrequency?: 'Monthly' | 'Annually' | null;
  paymentAmount?: number | null;
  lastPaymentDate?: string | null;
  paymentTypeLast4?: string | null;
  accountLink?: string | null;
};
type Tab = { name: string; subcategories?: string[]; };
type FinanceChild = { amount: number; date: string; };
type FinanceTile = { id: number; name: string; description: string; children: FinanceChild[]; };

const defaultTabs: Tab[] = [{ name: 'Banking' }, { name: 'AI' }];
const initialTiles: Tile[] = [];

// ...DROPPABLE TAB COMPONENT...
function DroppableTab({
  tab,
  isActive,
  isDragOver,
  onClick,
  onEdit,
  onDelete,
}: {
  tab: Tab;
  isActive: boolean;
  isDragOver: boolean;
  onClick: () => void;
  onEdit: () => void;
  onDelete?: () => void;
}) {
  const { setNodeRef, isOver } = useDroppable({ id: tab.name });
  return (
    <div
      ref={setNodeRef}
      className={`tab${isActive ? ' active' : ''}${isDragOver || isOver ? ' tab-drag-over' : ''}`}
      onClick={onClick}
    >
      {tab.name}
      <span
        className="edit-icon"
        title="Edit Tab"
        onClick={e => { e.stopPropagation(); onEdit(); }}
        role="button"
        tabIndex={0}
      >✏️</span>
      {onDelete && (
        <span
          className="edit-icon"
          title="Delete Tab"
          style={{ marginLeft: 4 }}
          onClick={e => { e.stopPropagation(); onDelete(); }}
          role="button"
          tabIndex={0}
        >🗑️</span>
      )}
    </div>
  );
}

// ...DROPPABLE SUBCATEGORY SECTION...
function DroppableSubcategorySection({
  subcategoryName,
  isDragOver,
  children,
}: {
  subcategoryName: string;
  isDragOver: boolean;
  children: React.ReactNode;
}) {
  const dropId = subcategoryName === '' ? 'uncategorized' : `subcategory-${subcategoryName}`;
  const { setNodeRef, isOver } = useDroppable({ id: dropId });
  return (
    <div
      ref={setNodeRef}
      style={{
        marginBottom: 32,
        padding: isOver || isDragOver ? '16px' : '0',
        borderRadius: isOver || isDragOver ? '12px' : '0',
        background: isOver || isDragOver ? '#e3f2fd' : 'transparent',
        border: isOver || isDragOver ? '2px dashed #1976d2' : 'none',
        transition: 'all 0.2s ease',
      }}
    >
      {children}
    </div>
  );
}

// ...FINANCE MANAGEMENT PAGE...
function FinanceManagementPage() {
  const [financeTiles, setFinanceTiles] = useState<FinanceTile[]>(() => {
    const saved = localStorage.getItem('financeTiles');
    return saved ? JSON.parse(saved) : [];
  });
  useEffect(() => {
    localStorage.setItem('financeTiles', JSON.stringify(financeTiles));
  }, [financeTiles]);

  const [tileForm, setTileForm] = useState({ name: '', description: '' });
  const [childForms, setChildForms] = useState<{ [tileId: number]: { amount: string; date: string } }>({});
  const today = new Date().toISOString().slice(0, 10);
  const [showTileModal, setShowTileModal] = useState(false);

  function handleAddTile(e: React.FormEvent) {
    e.preventDefault();
    setFinanceTiles(tiles => [
      ...tiles,
      { id: Date.now() + Math.random(), name: tileForm.name, description: tileForm.description, children: [] }
    ]);
    setTileForm({ name: '', description: '' });
  }

  function handleAddChild(tileId: number, e: React.FormEvent) {
    e.preventDefault();
    const { amount, date } = childForms[tileId] || {};
    if (!amount || isNaN(Number(amount))) return;
    setFinanceTiles(tiles =>
      tiles.map(tile =>
        tile.id === tileId
          ? { ...tile, children: [...tile.children, { amount: Number(amount), date: date || today }] }
          : tile
      )
    );
    setChildForms(forms => ({ ...forms, [tileId]: { amount: '', date: today } }));
  }

  const allDates = Array.from(
    new Set(financeTiles.flatMap(tile => tile.children.map(child => child.date)))
  ).sort();

  const chartData = allDates.map(date => {
    const entry: any = { date };
    financeTiles.forEach(tile => {
      const child = tile.children.find(c => c.date === date);
      entry[tile.name] = child ? child.amount : null;
    });
    return entry;
  });

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: 32 }}>
      <div style={{ display: 'flex', gap: 32, alignItems: 'flex-start', width: '100%' }}>
        {/* Tiles Column */}
        <div style={{ flex: 1, minWidth: 320 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h2 style={{ color: '#1976d2', margin: 0 }}>Finance Tiles</h2>
            <button
              className="create-tile-btn"
              style={{
                background: '#1976d2',
                color: '#fff',
                border: 'none',
                borderRadius: '50%',
                width: 32,
                height: 32,
                fontSize: 20,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 2px 8px #0001',
                cursor: 'pointer',
                marginLeft: 8
              }}
              title="Add web shortcut card"
              onClick={() => setShowTileModal(true)}
              aria-label="Add web shortcut card"
            >
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="9" y="4" width="2" height="12" rx="1" fill="currentColor"/>
                <rect x="4" y="9" width="12" height="2" rx="1" fill="currentColor"/>
              </svg>
            </button>
          </div>
          {showTileModal && (
            <Modal onClose={() => setShowTileModal(false)}>
              <form onSubmit={handleAddTile} style={{ padding: 16 }}>
                <h2 style={{ color: '#1976d2', marginBottom: 16 }}>Add New Tile</h2>
                <input
                  placeholder="Name"
                  value={tileForm.name}
                  onChange={e => setTileForm(f => ({ ...f, name: e.target.value }))}
                  required
                  style={{ width: '100%', marginBottom: 12, padding: 8 }}
                  autoFocus
                />
                <input
                  placeholder="Description"
                  value={tileForm.description}
                  onChange={e => setTileForm(f => ({ ...f, description: e.target.value }))}
                  required
                  style={{ width: '100%', marginBottom: 12, padding: 8 }}
                />
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                  <button type="button" onClick={() => setShowTileModal(false)} style={{ padding: '8px 16px', background: '#eee', color: '#333', border: 'none', borderRadius: 4 }}>Cancel</button>
                  <button type="submit" style={{ padding: '8px 16px', background: '#1976d2', color: '#fff', border: 'none', borderRadius: 4 }}>Add Tile</button>
                </div>
              </form>
            </Modal>
          )}
          {financeTiles.map(tile => (
            <div key={tile.id} style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px #0001', marginBottom: 24, padding: 16 }}>
              <div style={{ fontWeight: 700, fontSize: 18, color: '#1976d2' }}>{tile.name}</div>
              <div style={{ color: '#444', marginBottom: 8 }}>{tile.description}</div>
              <div>
                <form
                  onSubmit={e => handleAddChild(tile.id, e)}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}
                >
                  <input
                    type="number"
                    placeholder="Amount"
                    value={childForms[tile.id]?.amount || ''}
                    onChange={e => setChildForms(f => ({ ...f, [tile.id]: { ...f[tile.id], amount: e.target.value, date: f[tile.id]?.date || today } }))}
                    required
                    style={{ width: 90, padding: 6 }}
                  />
                  <input
                    type="date"
                    value={childForms[tile.id]?.date || today}
                    onChange={e => setChildForms(f => ({ ...f, [tile.id]: { ...f[tile.id], date: e.target.value, amount: f[tile.id]?.amount || '' } }))}
                    style={{ width: 140, padding: 6 }}
                  />
                  <button type="submit" style={{ padding: '6px 14px', background: '#1976d2', color: '#fff', border: 'none', borderRadius: 4 }}>Add</button>
                </form>
                <div>
                  {tile.children.map((child, idx) => (
                    <div key={idx} style={{ fontSize: 15, color: '#333', marginBottom: 2 }}>
                      ${child.amount.toFixed(2)} on {child.date}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        {/* Graph + Totals Column */}
        <div style={{ flex: 2, minWidth: 400, display: 'flex', flexDirection: 'column', gap: 24 }}>
          <div style={{ background: '#fff', borderRadius: 16, boxShadow: '0 4px 16px #0002', padding: 32 }}>
            <h2 style={{ color: '#1976d2', marginBottom: 16 }}>Finance Data Over Time</h2>
            <ResponsiveContainer width="100%" height={360}>
              <AreaChart data={chartData} margin={{ top: 24, right: 40, left: 0, bottom: 24 }}>
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <CartesianGrid strokeDasharray="3 3" />
                {financeTiles.map(tile => (
                  <Area
                    key={tile.id}
                    type="monotone"
                    dataKey={tile.name}
                    stroke={`#${Math.floor(Math.abs(Math.sin(tile.id)) * 16777215).toString(16).padStart(6, '0')}`}
                    fill={`#${Math.floor(Math.abs(Math.sin(tile.id + 1)) * 16777215).toString(16).padStart(6, '0')}33`}
                    strokeWidth={3}
                    dot={{ r: 5 }}
                    connectNulls
                  />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div style={{ background: '#f4f6fb', borderRadius: 10, padding: 20, boxShadow: '0 2px 8px #0001', maxWidth: '100%' }}>
            <div style={{ fontWeight: 600, color: '#1976d2', fontSize: 18, marginBottom: 8 }}>Totals by Date</div>
            {allDates.map(date => (
              <div key={date} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 16, marginBottom: 4, padding: '2px 0' }}>
                <span style={{ color: '#1976d2', fontWeight: 500 }}>{date}</span>
                <span style={{ color: '#333', fontWeight: 700 }}>&nbsp;&nbsp;&nbsp;{financeTiles.reduce((sum, tile) => {
                  const child = tile.children.find(c => c.date === date);
                  return sum + (child ? child.amount : 0);
                }, 0).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Add this helper function above the App function or inside it:
function getFileIcon(fileName: string) {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  if (["pptx", "pptm"].includes(ext)) {
    return <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALUAAACUCAMAAADifZgIAAAAb1BMVEXQRSX////NLgDQQyPz1c7nrKL++/vjnJDKGQDPOAjux8H33dfbemj88e734t7QPhjIBwDxzsjTUjb56eXgkIPYbVnOORDUW0LPQB3finz89fTsvbXXZlDuw7zLIwDSUTnlo5jfhHLosqradGHRSy2/JpyvAAAEmUlEQVR4nO2c6ZKiMBCAQ4IgiGS5QjhEDt//GRfCzI5COKakoK3N90urKP1INU3nREihUCgUCoVCoVAoFArFLyH8aIPfwi2MUUyO1lgJIZxa+Fz4Va0HHgKv3fkyjvy4CW+uJtAJaGvSti/1cyc83dxU+wdca0JxUZAoKW+6e9VegWdN2ohgGBc4DjP9ek01CbCsOW0j+HHPndIOZLbgrLsItvyoCmvPNeaMoVhzijF+RGZt64E0IGBZiwguCp6H2SVIF1sYgjUTEVydvGGCgGxNE7P2Zh85gNYE/yIgAFm/Ia2slbWyBmVNVgLKmjNrJWw78XetaZTZ67glDIw1q9bVWS3GdtrvW68vX67nT7Q2CjjWqyNE0/BWz+PbT2PjXVYQwLJG7PxnifP5T2iAsiaPyFkgZ8gyYVnz2Euv87gmhmftLl5lxPgDrbXTWVlvZJ16tmF4t2l9eNa5Z8YkStsiw3dux1sbRtpmhyAILm4gH5sUmY9gi7POGhNaIE/a49/NOqjLMKmiGFm4xU8yabmh93MFtLO22g+8KGX3t5u1x3Fbx1Ped0K4xRpP3tYv1ohYpkR7P2v/9R8IpZcV1oiwchwkh1m37U3GQTK2bn9w/EzubM27oLa+/ouWa6wR9UeNva81z7Msq0NEe51m1Ngya1SMGntfa1Z1Hw09Ftr8rq+ypvnB1k7/xRYJjvBszhr/jIwMB5aPsTbybsKcsBnrNMH8C8qGIXKMtdbQJWtNv9m3b4YVyUHWjghsVs9Yz3GQdSQihE63tRs8M7yHY6zdu3gaH6OX+pc1aYP5B2YN7+4Y61KsXqHRaNLpeyR4MHx6cFxX3UfD5H0chKOrpOPX3B9etq81uZtttYr7PyOPcWdFao1Px1q3dYjFvoadSTHKIHJrTkcJ5bhKFSeSq2TWeHx3B1kThmXVvswaO+MLd7YmfSqjKJJ0CaTWrJHMbu/9NFaO0zhJKet9CevBGjOOK9mU/N752ugG6qZn2kUfnf78FpF2do96o09b8/x0P2OrDSNc4GRiIAeedexqQRZWM2EE1HoRZf1fW3vyGYLnIhucNUG+HP70YodnTbic58pvN2sbnwtcNCvaegLrCGsjuNjZSVKcjtuaSjmkrdfRtXUeScmfOo/grNscEsg5Ioest16fr+GsWVhrnRpG6oBZ1cLvtSfnadj4VESmGeZwVhBNJmxkP1ljblkWXbbZzXpiZRx/vFhvJ7yR9cTvwrYm8vV8mIK2fiShnKdePThrHl+MCUBbr8nXyno3a9NaFoFn/dh6z+n71ra7gBdv9yrfyHqyV/DDlq/yrayX17pv7vz/7itQ1spaWW9lvXKzKyhrxHMnLF+2xn+CNeLdzJwfN+ZteU80HOuO/siHAvvVyXOv6/cbQ9jZjUh3vAaNq/LmXWbm64BZC8Q5BShukjLTl3bwwLEWdIduUNIdulFfZhodmLWgrde6aC9IU05EO0Trb7qDAfDdMTPvEhgfY90hdl+SLtprPfgYa4Hot/TnG+jpx1gL+tNQijNtTDuDf5rPANImyM27sQqFQqFQKBQKhUKhUCjA8BcSnIVyN1JPfAAAAABJRU5ErkJggg==" alt="pptx" style={{ width: 24, height: 24, marginRight: 10, verticalAlign: 'middle' }} />;
  }
  if (["doc", "docx"].includes(ext)) {
    return <span style={{ color: '#2b579a', fontSize: 20, marginRight: 10 }}>📄</span>; // Word
  }
  if (["ppt", "pptx"].includes(ext)) {
    return <span style={{ color: '#b7472a', fontSize: 20, marginRight: 10 }}>📊</span>; // PowerPoint
  }
  if (["xls", "xlsx"].includes(ext)) {
    return <span style={{ color: '#217346', fontSize: 20, marginRight: 10 }}>📈</span>; // Excel
  }
  if (ext === "pdf") {
    return <span style={{ color: '#d32f2f', fontSize: 20, marginRight: 10 }}>📕</span>; // PDF
  }
  if (["jpg", "jpeg", "png", "gif", "bmp", "svg", "webp"].includes(ext)) {
    return <span style={{ color: '#1976d2', fontSize: 20, marginRight: 10 }}>🖼️</span>; // Image
  }
  if (["txt", "md", "rtf"].includes(ext)) {
    return <span style={{ color: '#616161', fontSize: 20, marginRight: 10 }}>📄</span>; // Text
  }
  return <span style={{ color: '#888', fontSize: 20, marginRight: 10 }}>📁</span>; // Generic
}

// Add this helper function above the App function or inside it:
function getCommonFolder(files: File[]) {
  if (!files.length) return '';
  const paths = files.map(f => f.webkitRelativePath || f.name);
  if (paths.some(p => !p.includes('/'))) return '';
  const splitPaths = paths.map(p => p.split('/').slice(0, -1));
  let common = splitPaths[0];
  for (let i = 1; i < splitPaths.length; i++) {
    let j = 0;
    while (j < common.length && common[j] === splitPaths[i][j]) j++;
    common = common.slice(0, j);
    if (!common.length) break;
  }
  return common.join('/');
}

// Add this helper function above the App function or inside it:
function formatCurrency(amount: number | null | undefined) {
  if (typeof amount !== 'number' || isNaN(amount)) return '';
  return amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}
function formatDate(dateStr: string | null | undefined) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
}

// ...START OF MAIN APP...
function App() {
  // --- WebTabs state and handlers ---
  const [tabs, setTabs] = useState<Tab[]>(() => {
    const saved = localStorage.getItem('tabs');
    return saved ? JSON.parse(saved) : defaultTabs;
  });
  const [tiles, setTiles] = useState<Tile[]>(() => {
    const saved = localStorage.getItem('tiles');
    return saved ? JSON.parse(saved) : initialTiles;
  });

  useEffect(() => {
    setTiles(tiles => {
      if (tiles.length > 0 && !('id' in tiles[0])) {
        const migrated = tiles.map(tile => ({
          ...tile,
          id: Date.now() + Math.random()
        }));
        localStorage.setItem('tiles', JSON.stringify(migrated));
        return migrated;
      }
      return tiles;
    });
    // eslint-disable-next-line
  }, []);

  const [activeTab, setActiveTab] = useState<string>(tabs[0]?.name || '');
  const [showTileModal, setShowTileModal] = useState(false);
  const [showTabModal, setShowTabModal] = useState(false);
  const [tabModalMode, setTabModalMode] = useState<'add' | 'edit'>('add');
  const [form, setForm] = useState<Omit<Tile, 'id'>>({
    name: '',
    description: '',
    link: '',
    category: tabs[0]?.name || '',
    subcategory: '',
    logo: '',
    appType: 'web',
    localPath: '',
    paidSubscription: false,
    paymentFrequency: null,
    paymentAmount: null,
    lastPaymentDate: null,
    paymentTypeLast4: '',
    accountLink: '',
  });
  const [editTileId, setEditTileId] = useState<number | null>(null);
  const [editingTabIndex, setEditingTabIndex] = useState<number | null>(null);
  const [tabFormName, setTabFormName] = useState<string>('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [tileToDeleteId, setTileToDeleteId] = useState<number | null>(null);
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [restoreData, setRestoreData] = useState<{ tiles: Tile[]; tabs: Tab[] } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Banner Title state
  const [bannerTitle, setBannerTitle] = useState<string>(() => {
    const saved = localStorage.getItem('bannerTitle');
    return saved || "Bill's Applications";
  });
  const [showBannerTitleModal, setShowBannerTitleModal] = useState(false);
  const [bannerTitleForm, setBannerTitleForm] = useState<string>('');
  
  // Subcategory state
  const [showSubcategoryModal, setShowSubcategoryModal] = useState(false);
  const [subcategoryModalMode, setSubcategoryModalMode] = useState<'add' | 'edit'>('add');
  const [subcategoryForm, setSubcategoryForm] = useState<string>('');
  const [editingSubcategoryIndex, setEditingSubcategoryIndex] = useState<number | null>(null);
  
  // APP Report sorting state
  const [sortColumn, setSortColumn] = useState<'name' | 'frequency' | 'paymentType'>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  // Sort function for APP Report
  const handleSort = (column: 'name' | 'frequency' | 'paymentType') => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };
  
  // Sort tiles for APP Report
  const sortedReportTiles = React.useMemo(() => {
    const filtered = tiles.filter(t => t.paidSubscription);
    return filtered.sort((a, b) => {
      let aValue: string, bValue: string;
      
      switch (sortColumn) {
        case 'name':
          aValue = a.name.toLowerCase();
          bValue = b.name.toLowerCase();
          break;
        case 'frequency':
          aValue = a.paymentFrequency || '';
          bValue = b.paymentFrequency || '';
          break;
        case 'paymentType':
          aValue = a.paymentTypeLast4 || '';
          bValue = b.paymentTypeLast4 || '';
          break;
        default:
          return 0;
      }
      
      if (sortDirection === 'asc') {
        return aValue.localeCompare(bValue);
      } else {
        return bValue.localeCompare(aValue);
      }
    });
  }, [tiles, sortColumn, sortDirection]);
  const [dragOverTab, setDragOverTab] = useState<string | null>(null);
  const [dragOverSubcategory, setDragOverSubcategory] = useState<string | null>(null);
  const [mainMenu, setMainMenu] = useState<'webtabs' | 'finance' | 'files'>('webtabs');
  const [pickedFolders, setPickedFolders] = useState<Array<{
    name: string;
    path: string;
    files: File[];
    fileNames: string[];
    expanded: boolean;
    needsRepick?: boolean;
  }>>(() => {
    // Load from localStorage
    const saved = localStorage.getItem('pickedFolders');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed)
        ? parsed.map(f => ({ ...f, files: [], expanded: false, needsRepick: true }))
        : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    // Save folder metadata (not files) to localStorage
    localStorage.setItem(
      'pickedFolders',
      JSON.stringify(
        pickedFolders.map(f => ({
          name: f.name,
          path: f.path,
          fileNames: f.files.length ? f.files.map(file => file.webkitRelativePath?.replace(f.path + '/', '') || file.name) : f.fileNames || [],
        }))
      )
    );
  }, [pickedFolders]);

  useEffect(() => {
    localStorage.setItem('tabs', JSON.stringify(tabs));
  }, [tabs]);
  useEffect(() => {
    localStorage.setItem('tiles', JSON.stringify(tiles));
  }, [tiles]);
  useEffect(() => {
    if (activeTab !== 'APP Report' && !tabs.find(tab => tab.name === activeTab)) {
      setActiveTab(tabs[0]?.name || '');
    }
  }, [tabs, activeTab]);
  useEffect(() => {
    localStorage.setItem('bannerTitle', bannerTitle);
    document.title = bannerTitle;
  }, [bannerTitle]);

  // WebTabs handlers (same as previous code)
  const handleCreateTile = () => {
    setShowTileModal(true);
    setEditTileId(null);
    setForm({ name: '', description: '', link: '', category: activeTab, subcategory: '', logo: '', appType: 'web', localPath: '', paidSubscription: false, paymentFrequency: null, paymentAmount: null, lastPaymentDate: null, paymentTypeLast4: '', accountLink: '' });
  };
  const handleEditTile = (tileId: number) => {
    const tile = tiles.find(t => t.id === tileId);
    if (!tile) return;
    setShowTileModal(true);
    setEditTileId(tileId);
    setForm({
      name: tile.name,
      description: tile.description,
      link: tile.link,
      category: tile.category,
      subcategory: tile.subcategory || '',
      logo: tile.logo,
      appType: tile.appType || 'web',
      localPath: tile.localPath || '',
      paidSubscription: tile.paidSubscription || false,
      paymentFrequency: tile.paymentFrequency || null,
      paymentAmount: tile.paymentAmount || null,
      lastPaymentDate: tile.lastPaymentDate || null,
      paymentTypeLast4: tile.paymentTypeLast4 || '',
      accountLink: tile.accountLink || '',
    });
  };
  const handleDeleteTile = (tileId: number) => {
    setTileToDeleteId(tileId);
    setShowDeleteModal(true);
  };
  const confirmDeleteTile = () => {
    if (tileToDeleteId !== null) {
      setTiles(tiles => tiles.filter(t => t.id !== tileToDeleteId));
    }
    setShowDeleteModal(false);
    setTileToDeleteId(null);
  };
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, type, checked } = e.target;
    if (type === 'checkbox') {
      setForm(f => ({ ...f, [name]: checked }));
    } else {
      setForm({ ...form, [name]: e.target.value });
    }
  };
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editTileId !== null) {
      setTiles(tiles =>
        tiles.map(t =>
          t.id === editTileId
            ? { ...t, ...form }
            : t
        )
      );
    } else {
      setTiles([...tiles, { ...form, id: Date.now() + Math.random() }]);
    }
    setShowTileModal(false);
    setEditTileId(null);
  };
  const openAddTabModal = () => {
    setTabModalMode('add');
    setTabFormName('');
    setShowTabModal(true);
    setEditingTabIndex(null);
  };
  const openEditTabModal = (idx: number) => {
    setTabModalMode('edit');
    setTabFormName(tabs[idx].name);
    setShowTabModal(true);
    setEditingTabIndex(idx);
  };
  const handleTabFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newName = tabFormName.trim();
    if (!newName || tabs.some((tab, i) => tab.name === newName && (tabModalMode === 'add' || i !== editingTabIndex))) return;
    if (tabModalMode === 'add') {
      setTabs([...tabs, { name: newName }]);
      setActiveTab(newName);
    } else if (editingTabIndex !== null) {
      const oldName = tabs[editingTabIndex].name;
      const updatedTabs = tabs.map((tab, i) => i === editingTabIndex ? { name: newName } : tab);
      const updatedTiles = tiles.map(tile =>
        tile.category === oldName ? { ...tile, category: newName } : tile
      );
      setTabs(updatedTabs);
      setTiles(updatedTiles);
      setActiveTab(newName);
    }
    setShowTabModal(false);
    setEditingTabIndex(null);
    setTabFormName('');
  };
  const handleDeleteTab = (idx: number) => {
    const tabName = tabs[idx].name;
    if (!window.confirm(`Delete tab "${tabName}"? All tiles in this category will also be deleted.`)) return;
    const updatedTabs = tabs.filter((_, i) => i !== idx);
    const updatedTiles = tiles.filter(tile => tile.category !== tabName);
    setTabs(updatedTabs);
    setTiles(updatedTiles);
    setActiveTab(updatedTabs[0]?.name || '');
  };
  const openBannerTitleModal = () => {
    setBannerTitleForm(bannerTitle);
    setShowBannerTitleModal(true);
  };
  const handleBannerTitleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTitle = bannerTitleForm.trim();
    if (!newTitle) return;
    setBannerTitle(newTitle);
    setShowBannerTitleModal(false);
  };
  const openAddSubcategoryModal = () => {
    setSubcategoryModalMode('add');
    setSubcategoryForm('');
    setShowSubcategoryModal(true);
    setEditingSubcategoryIndex(null);
  };
  const openEditSubcategoryModal = (idx: number) => {
    const currentTab = tabs.find(t => t.name === activeTab);
    if (!currentTab || !currentTab.subcategories) return;
    setSubcategoryModalMode('edit');
    setSubcategoryForm(currentTab.subcategories[idx]);
    setShowSubcategoryModal(true);
    setEditingSubcategoryIndex(idx);
  };
  const handleSubcategoryFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newSubcategory = subcategoryForm.trim();
    if (!newSubcategory) return;
    
    const tabIndex = tabs.findIndex(t => t.name === activeTab);
    if (tabIndex === -1) return;
    
    const currentTab = tabs[tabIndex];
    const subcategories = currentTab.subcategories || [];
    
    if (subcategoryModalMode === 'add') {
      // Check if subcategory already exists
      if (subcategories.includes(newSubcategory)) {
        alert('Subcategory already exists!');
        return;
      }
      // Add new subcategory
      const updatedTabs = tabs.map((tab, i) =>
        i === tabIndex ? { ...tab, subcategories: [...subcategories, newSubcategory] } : tab
      );
      setTabs(updatedTabs);
    } else if (editingSubcategoryIndex !== null) {
      // Edit existing subcategory
      const oldSubcategory = subcategories[editingSubcategoryIndex];
      const updatedSubcategories = subcategories.map((sub, i) =>
        i === editingSubcategoryIndex ? newSubcategory : sub
      );
      const updatedTabs = tabs.map((tab, i) =>
        i === tabIndex ? { ...tab, subcategories: updatedSubcategories } : tab
      );
      // Update all tiles that had the old subcategory
      const updatedTiles = tiles.map(tile =>
        tile.category === activeTab && tile.subcategory === oldSubcategory
          ? { ...tile, subcategory: newSubcategory }
          : tile
      );
      setTabs(updatedTabs);
      setTiles(updatedTiles);
    }
    
    setShowSubcategoryModal(false);
    setEditingSubcategoryIndex(null);
    setSubcategoryForm('');
    setSubcategoryModalMode('add');
  };
  const handleDeleteSubcategory = (idx: number) => {
    const currentTab = tabs.find(t => t.name === activeTab);
    if (!currentTab || !currentTab.subcategories) return;
    
    const subcategoryToDelete = currentTab.subcategories[idx];
    if (!window.confirm(`Delete subcategory "${subcategoryToDelete}"? Tiles in this subcategory will become uncategorized.`)) return;
    
    const tabIndex = tabs.findIndex(t => t.name === activeTab);
    const updatedSubcategories = currentTab.subcategories.filter((_, i) => i !== idx);
    const updatedTabs = tabs.map((tab, i) =>
      i === tabIndex ? { ...tab, subcategories: updatedSubcategories } : tab
    );
    // Remove subcategory from tiles
    const updatedTiles = tiles.map(tile =>
      tile.category === activeTab && tile.subcategory === subcategoryToDelete
        ? { ...tile, subcategory: '' }
        : tile
    );
    setTabs(updatedTabs);
    setTiles(updatedTiles);
  };
  function handleBackup() {
    const tiles = localStorage.getItem('tiles');
    const tabs = localStorage.getItem('tabs');
    const backup = {
      tiles: tiles ? JSON.parse(tiles) : [],
      tabs: tabs ? JSON.parse(tabs) : [],
      backupDate: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bills-apps-backup-${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
  function handleRestoreClick() {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  }
  function handleRestoreFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (data && Array.isArray(data.tiles) && Array.isArray(data.tabs)) {
          setRestoreData({ tiles: data.tiles, tabs: data.tabs });
          setShowRestoreModal(true);
        } else {
          alert('Invalid backup file.');
        }
      } catch {
        alert('Invalid backup file.');
      }
    };
    reader.readAsText(file);
  }
  function confirmRestore() {
    if (restoreData) {
      setTiles(restoreData.tiles);
      setTabs(restoreData.tabs);
      setShowRestoreModal(false);
      setRestoreData(null);
      setActiveTab(restoreData.tabs[0]?.name || '');
    }
  }
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );
  const filteredTiles = tiles.filter(tile => tile.category === activeTab);
  const filteredTileIds = filteredTiles.map(tile => tile.id);
  
  // Group tiles by subcategory
  const currentTab = tabs.find(t => t.name === activeTab);
  const subcategories = currentTab?.subcategories || [];
  const tilesWithoutSubcategory = filteredTiles.filter(t => !t.subcategory);
  const tilesBySubcategory = subcategories.map(sub => ({
    name: sub,
    tiles: filteredTiles.filter(t => t.subcategory === sub),
  }));
  
  const columns = 3;
  const remainder = filteredTiles.length % columns;
  const placeholders = remainder === 0 ? 0 : columns - remainder;
  function handleDragEnd(event: any) {
    const { active, over } = event;
    setDragOverTab(null);
    setDragOverSubcategory(null);
    
    // Check if dropped on a tab
    if (over && typeof over.id === 'string' && tabs.some(tab => tab.name === over.id)) {
      setTiles(tiles =>
        tiles.map(tile =>
          tile.id === active.id ? { ...tile, category: over.id } : tile
        )
      );
      setActiveTab(over.id);
      return;
    }
    
    // Check if dropped on a subcategory
    if (over && typeof over.id === 'string' && over.id.startsWith('subcategory-')) {
      const subcategoryName = over.id.replace('subcategory-', '');
      setTiles(tiles =>
        tiles.map(tile =>
          tile.id === active.id ? { ...tile, subcategory: subcategoryName } : tile
        )
      );
      return;
    }
    
    // Check if dropped on "uncategorized" area
    if (over && over.id === 'uncategorized') {
      setTiles(tiles =>
        tiles.map(tile =>
          tile.id === active.id ? { ...tile, subcategory: '' } : tile
        )
      );
      return;
    }
    
    if (!over || active.id === over.id) return;
    const oldIndex = filteredTileIds.indexOf(active.id);
    const newIndex = filteredTileIds.indexOf(over.id);
    if (oldIndex === -1 || newIndex === -1) return;
    const reordered = arrayMove(filteredTiles, oldIndex, newIndex);
    const newTiles: Tile[] = [];
    let filteredIdx = 0;
    for (let i = 0; i < tiles.length; i++) {
      if (tiles[i].category === activeTab) {
        newTiles.push(reordered[filteredIdx++]);
      } else {
        newTiles.push(tiles[i]);
      }
    }
    setTiles(newTiles);
  }
  const TrashIcon = (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="6.5" y="8" width="1.5" height="6" rx="0.75" fill="#888"/>
      <rect x="12" y="8" width="1.5" height="6" rx="0.75" fill="#888"/>
      <rect x="9.25" y="8" width="1.5" height="6" rx="0.75" fill="#888"/>
      <rect x="4" y="5" width="12" height="2" rx="1" fill="#888"/>
      <rect x="7" y="3" width="6" height="2" rx="1" fill="#888"/>
      <rect x="3" y="7" width="14" height="10" rx="2" stroke="#888" strokeWidth="1.5" fill="none"/>
    </svg>
  );
  function SortableTile({ tile, idx }: { tile: Tile; idx: number }) {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: tile.id });
    
    const handleTileClick = (e: React.MouseEvent) => {
      if (tile.appType === 'local') {
        e.preventDefault();
        // Show path and copy to clipboard
        const pathToCopy = tile.localPath || '';
        if (pathToCopy) {
          navigator.clipboard.writeText(pathToCopy).then(() => {
            alert(`Path copied to clipboard!\n\n${pathToCopy}\n\nNote: Web browsers cannot launch .exe files directly. Please paste this path into Windows Run (Win+R) or File Explorer.`);
          }).catch(() => {
            alert(`Application Path:\n\n${pathToCopy}\n\nNote: Web browsers cannot launch .exe files directly. Please copy this path manually and paste into Windows Run (Win+R) or File Explorer.`);
          });
        } else if (tile.link) {
          // If there's a fallback link, open it
          window.open(tile.link, '_blank');
        }
      }
      // For 'web' and 'protocol' types, the default anchor behavior handles it
    };
    
    return (
      <a
        className="tile"
        href={tile.appType === 'local' && !tile.link ? '#' : tile.link}
        target="_blank"
        rel="noopener noreferrer"
        ref={setNodeRef}
        onClick={handleTileClick}
        style={{
          position: 'relative',
          textDecoration: 'none',
          color: 'inherit',
          userSelect: 'none',
          transform: CSS.Transform.toString(transform),
          transition,
          boxShadow: isDragging
            ? '0 8px 32px #1976d244'
            : '0 2px 16px #0002',
          zIndex: isDragging ? 100 : undefined,
          cursor: 'pointer',
        }}
        {...attributes}
        {...listeners}
      >
        {tile.logo && (
          <img
            src={tile.logo}
            alt={tile.name + ' logo'}
            className="tile-logo"
          />
        )}
        <div className="tile-content">
          <div className="tile-title">
            {tile.name}
            {tile.appType === 'local' && (
              <span style={{ marginLeft: 8, fontSize: 14, color: '#ff9800' }} title="Local Application (click to copy path)">💻</span>
            )}
            {tile.appType === 'protocol' && (
              <span style={{ marginLeft: 8, fontSize: 14, color: '#9c27b0' }} title="Custom Protocol Handler">🔗</span>
            )}
          </div>
          <p className="tile-desc">{tile.description}</p>
        </div>
        {/* ICONS ROW AT BOTTOM */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          gap: 10,
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 10,
          padding: '0 12px',
        }}>
          <span
            className="edit-icon"
            title="Edit web shortcut card"
            style={{
              color: '#888',
              fontSize: 18,
              background: 'none',
              borderRadius: '50%',
              padding: 2,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease',
            }}
            onClick={e => { e.preventDefault(); e.stopPropagation(); handleEditTile(tile.id); }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = '#1976d2';
              e.currentTarget.style.transform = 'scale(1.2) rotate(5deg)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = '#888';
              e.currentTarget.style.transform = 'scale(1) rotate(0deg)';
            }}
            role="button"
            tabIndex={0}
          >✏️</span>
          {/* Add Tile Button (blue, only on the first tile of the grid for the tab) */}
          {tile.paidSubscription && (
            <span
              className="edit-icon"
              style={{
                color: '#888',
                fontSize: 18,
                background: 'none',
                borderRadius: '50%',
                padding: 2,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onMouseEnter={e => {
                const popup = document.createElement('div');
                popup.className = 'tile-popup';
                popup.style.position = 'fixed';
                popup.style.left = e.clientX + 16 + 'px';
                popup.style.top = e.clientY - 16 + 'px';
                popup.style.background = '#fff';
                popup.style.color = '#222';
                popup.style.border = '1px solid #1976d2';
                popup.style.borderRadius = '8px';
                popup.style.boxShadow = '0 4px 16px #0002';
                popup.style.padding = '14px 20px';
                popup.style.fontSize = '15px';
                popup.style.zIndex = '9999';
                popup.innerHTML = `
                  <div><b>Paid Subscription:</b> YES</div>
                  <div><b>Payment Frequency:</b> ${tile.paymentFrequency || ''}</div>
                  <div><b>Payment Amount:</b> ${formatCurrency(tile.paymentAmount)}</div>
                  <div><b>Payment Date:</b> ${formatDate(tile.lastPaymentDate)}</div>
                  <div><b>Payment Type:</b> ${tile.paymentTypeLast4 ? '**** ' + tile.paymentTypeLast4 : ''}</div>
                `;
                document.body.appendChild(popup);
                (e.currentTarget as any)._tilePopup = popup;
              }}
              onMouseLeave={e => {
                const popup = (e.currentTarget as any)._tilePopup;
                if (popup) {
                  document.body.removeChild(popup);
                  (e.currentTarget as any)._tilePopup = null;
                }
              }}
              onMouseOut={e => {
                const popup = (e.currentTarget as any)._tilePopup;
                if (popup) {
                  document.body.removeChild(popup);
                  (e.currentTarget as any)._tilePopup = null;
                }
              }}
            >
              $
            </span>
          )}
          {tile.accountLink && (
            <a
              href={tile.accountLink}
              target="_blank"
              rel="noopener noreferrer"
              title="Account Link"
              style={{
                color: '#888',
                fontSize: 18,
                background: 'none',
                borderRadius: '50%',
                padding: 2,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                textDecoration: 'none',
              }}
              onClick={e => e.stopPropagation()}
            >
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="10" cy="10" r="8" stroke="#888" strokeWidth="2" fill="none"/>
                <path d="M13.5 10A3.5 3.5 0 0 1 10 13.5 3.5 3.5 0 0 1 6.5 10 3.5 3.5 0 0 1 10 6.5 3.5 3.5 0 0 1 13.5 10Z" stroke="#888" strokeWidth="2"/>
                <path d="M10 7.5V10L11.5 11.5" stroke="#888" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </a>
          )}
          <span
            className="edit-icon"
            title="Delete web shortcut card"
            style={{
              color: '#888',
              fontSize: 18,
              background: 'none',
              borderRadius: '50%',
              padding: 2,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease',
            }}
            onClick={e => { e.preventDefault(); e.stopPropagation(); handleDeleteTile(tile.id); }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'scale(1.2)';
              const svg = e.currentTarget.querySelector('svg');
              if (svg) {
                const rects = svg.querySelectorAll('rect');
                rects.forEach(rect => rect.setAttribute('fill', '#e53935'));
                rects.forEach(rect => rect.setAttribute('stroke', '#e53935'));
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'scale(1)';
              const svg = e.currentTarget.querySelector('svg');
              if (svg) {
                const rects = svg.querySelectorAll('rect');
                rects.forEach(rect => rect.setAttribute('fill', '#888'));
                rects.forEach(rect => rect.setAttribute('stroke', '#888'));
              }
            }}
            role="button"
            tabIndex={0}
          >{TrashIcon}</span>
        </div>
      </a>
    );
  }
  const webTabsIcon = (
    <span style={{ fontSize: 22, marginRight: 12 }}>🌐</span>
  );
  const financeIcon = (
    <span style={{ fontSize: 22, marginRight: 12 }}>💰</span>
  );

  const handleFilesPicked = (e: React.ChangeEvent<HTMLInputElement>, repickIdx?: number) => {
    const files = e.target.files ? Array.from(e.target.files) : [];
    if (!files.length) return;
    // Get common folder path
    const paths = files.map(f => f.webkitRelativePath || f.name);
    const splitPaths = paths.map(p => p.split('/').slice(0, -1));
    let common = splitPaths[0];
    for (let i = 1; i < splitPaths.length; i++) {
      let j = 0;
      while (j < common.length && common[j] === splitPaths[i][j]) j++;
      common = common.slice(0, j);
      if (!common.length) break;
    }
    const folderPath = common.join('/');
    const folderName = folderPath.split('/').pop() || folderPath || '[Root]';
    const fileNames = files.map(file => file.webkitRelativePath?.replace(folderPath + '/', '') || file.name);
    setPickedFolders(folders => {
      if (typeof repickIdx === 'number') {
        // Replace the folder at repickIdx
        return folders.map((f, i) =>
          i === repickIdx
            ? { name: folderName, path: folderPath, files, fileNames, expanded: true, needsRepick: false }
            : f
        );
      }
      // Add new folder
      return [
        ...folders,
        { name: folderName, path: folderPath, files, fileNames, expanded: false, needsRepick: false },
      ];
    });
  };
  const toggleFolder = (idx: number) => {
    setPickedFolders(folders =>
      folders.map((f, i) => i === idx ? { ...f, expanded: !f.expanded } : f)
    );
  };
  const deleteFolder = (idx: number) => {
    setPickedFolders(folders => folders.filter((_, i) => i !== idx));
  };
  const repickRefs = useRef<Array<HTMLInputElement | null>>([]);

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <aside
        style={{
          position: 'fixed',
          left: 0,
          top: 0,
          width: 220,
          height: '100vh',
          background: 'linear-gradient(180deg, #0b1440 0%, #0a2f86 45%, #082a72 75%, #071f5e 100%)',
          color: '#fff',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'stretch',
          padding: '0 0 24px 0',
          boxShadow: '2px 0 12px #0002',
          zIndex: 100,
        }}
      >
        <div style={{
          fontWeight: 700,
          fontSize: 24,
          padding: '32px 0 24px 0',
          textAlign: 'center',
          letterSpacing: 1,
          borderBottom: '1px solid #283593',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}>
          <img
            src="https://flagheroes.us/wp-content/uploads/2024/04/cropped-Flag-Heroes-2000-x-2000-px-260x229.png"
            alt="Flag Heroes logo"
            style={{ width: 48, height: 48, objectFit: 'contain', marginBottom: 8 }}
          />
          Bill's Apps
        </div>
        <nav style={{ marginTop: 32, flex: 1 }}>
          <div
            onClick={() => setMainMenu('webtabs')}
            style={{
              display: 'flex',
              alignItems: 'center',
              padding: '14px 32px',
              cursor: 'pointer',
              background: mainMenu === 'webtabs' ? '#1976d2' : 'none',
              color: mainMenu === 'webtabs' ? '#fff' : '#bbdefb',
              fontWeight: mainMenu === 'webtabs' ? 700 : 500,
              fontSize: 18,
              borderLeft: mainMenu === 'webtabs' ? '4px solid #fff' : '4px solid transparent',
              transition: 'background 0.2s, color 0.2s',
              position: 'relative',
            }}
          >
            {webTabsIcon} WebTabs
            {mainMenu === 'webtabs' && (
              <button
                className="add-tab-btn"
                onClick={e => { e.stopPropagation(); openAddTabModal(); }}
                title="Add Tab"
                style={{
                  marginLeft: 'auto',
                  background: '#f4f6fb',
                  color: '#1976d2',
                  border: '2px solid #1976d2',
                  borderRadius: '50%',
                  width: 32,
                  height: 32,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 2px 8px #0001',
                  cursor: 'pointer',
                  marginRight: -8,
                  padding: 0
                }}
                aria-label="Add Tab"
              >
                <svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="9" y="4" width="2" height="12" rx="1" fill="#1976d2"/>
                  <rect x="4" y="9" width="12" height="2" rx="1" fill="#1976d2"/>
                </svg>
              </button>
            )}
          </div>
          {/* WebTabs Submenu: Tabs List */}
          {mainMenu === 'webtabs' && (
            <div style={{ marginLeft: 24, marginTop: 4, marginBottom: 12 }}>
              {tabs.map((tab, idx) => (
                <div
                  key={tab.name}
                  onClick={() => setActiveTab(tab.name)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '8px 0 8px 8px',
                    cursor: 'pointer',
                    color: activeTab === tab.name ? '#1976d2' : '#bbdefb',
                    fontWeight: activeTab === tab.name ? 700 : 500,
                    background: activeTab === tab.name ? '#e3f2fd' : 'none',
                    borderRadius: 6,
                    marginBottom: 2,
                    transition: 'background 0.2s, color 0.2s',
                  }}
                >
                  <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tab.name}</span>
                </div>
              ))}
              {/* APP REPORT entry */}
              <div
                onClick={() => setActiveTab('APP Report')}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  padding: '8px 0 8px 8px',
                  cursor: 'pointer',
                  color: activeTab === 'APP Report' ? '#1976d2' : '#bbdefb',
                  fontWeight: activeTab === 'APP Report' ? 700 : 500,
                  background: activeTab === 'APP Report' ? '#e3f2fd' : 'none',
                  borderRadius: 6,
                  marginTop: 8,
                  transition: 'background 0.2s, color 0.2s',
                }}
              >
                <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>APP Report</span>
              </div>
            </div>
          )}
          <div
            onClick={() => setMainMenu('finance')}
            style={{
              display: 'flex',
              alignItems: 'center',
              padding: '14px 32px',
              cursor: 'pointer',
              background: mainMenu === 'finance' ? '#1976d2' : 'none',
              color: mainMenu === 'finance' ? '#fff' : '#bbdefb',
              fontWeight: mainMenu === 'finance' ? 700 : 500,
              fontSize: 18,
              borderLeft: mainMenu === 'finance' ? '4px solid #fff' : '4px solid transparent',
              transition: 'background 0.2s, color 0.2s',
            }}
          >
            {financeIcon} Finance Management
          </div>
          <div
            onClick={() => setMainMenu('files')}
            style={{
              display: 'flex',
              alignItems: 'center',
              padding: '14px 32px',
              cursor: 'pointer',
              background: mainMenu === 'files' ? '#1976d2' : 'none',
              color: mainMenu === 'files' ? '#fff' : '#bbdefb',
              fontWeight: mainMenu === 'files' ? 700 : 500,
              fontSize: 18,
              borderLeft: mainMenu === 'files' ? '4px solid #fff' : '4px solid transparent',
              transition: 'background 0.2s, color 0.2s',
            }}
          >
            <span style={{ fontSize: 22, marginRight: 12 }}>📁</span> Files
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <div style={{ marginLeft: 220, minHeight: '100vh', position: 'relative', padding: '0 24px 32px 24px' }}>
        <div className="header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', maxWidth: '100%', margin: '0 -24px', padding: '28px 24px 12px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {bannerTitle}
            <span
              className="edit-icon"
              title="Edit Banner Title"
              style={{ fontSize: 24, color: '#fff', cursor: 'pointer', background: '#ffffff22', borderRadius: '50%', padding: 6, transition: 'background 0.2s' }}
              onClick={openBannerTitleModal}
              onMouseEnter={e => e.currentTarget.style.background = '#ffffff33'}
              onMouseLeave={e => e.currentTarget.style.background = '#ffffff22'}
              role="button"
              tabIndex={0}
            >✏️</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <button
              style={{
                background: '#1976d2',
                color: '#fff',
                border: 'none',
                borderRadius: 6,
                padding: '10px 20px',
                fontSize: '1rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
              onClick={handleBackup}
            >
              Backup Data
            </button>
            <button
              style={{
                background: '#43a047',
                color: '#fff',
                border: 'none',
                borderRadius: 6,
                padding: '10px 20px',
                fontSize: '1rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
              onClick={handleRestoreClick}
            >
              Restore Data
            </button>
            <input
              type="file"
              accept="application/json"
              ref={fileInputRef}
              style={{ display: 'none' }}
              onChange={handleRestoreFileChange}
            />
          </div>
        </div>
        {mainMenu === 'webtabs' && (
          <>
            {/* Active Tab Title Row */}
            {activeTab !== 'APP Report' && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '32px 0 24px 0', minHeight: 48 }}>
              <h1 style={{ color: '#1976d2', fontSize: 28, fontWeight: 700, margin: 0, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{activeTab}</h1>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginLeft: 16 }}>
                <button
                  onClick={openAddSubcategoryModal}
                  title="Manage Subcategories"
                  style={{
                    background: '#e3f2fd',
                    color: '#1976d2',
                    border: '2px solid #1976d2',
                    borderRadius: 6,
                    padding: '8px 16px',
                    fontSize: 14,
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    transition: 'all 0.2s ease',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#1976d2';
                    e.currentTarget.style.color = '#fff';
                    e.currentTarget.style.transform = 'scale(1.05)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(25, 118, 210, 0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = '#e3f2fd';
                    e.currentTarget.style.color = '#1976d2';
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  📁 Subcategories
                </button>
                <span
                  className="edit-icon"
                  title="Edit Tab"
                  style={{ fontSize: 22, color: '#1976d2', cursor: 'pointer', background: '#e3f2fd', borderRadius: '50%', padding: 6, transition: 'all 0.2s ease' }}
                  onClick={() => openEditTabModal(tabs.findIndex(tab => tab.name === activeTab))}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#1976d2';
                    e.currentTarget.style.transform = 'scale(1.15) rotate(5deg)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = '#e3f2fd';
                    e.currentTarget.style.transform = 'scale(1) rotate(0deg)';
                  }}
                  role="button"
                  tabIndex={0}
                >✏️</span>
                {tabs.length > 1 && (
                  <span
                    className="edit-icon"
                    title="Delete Tab"
                    style={{ fontSize: 22, color: '#e53935', cursor: 'pointer', background: '#ffebee', borderRadius: '50%', padding: 6, transition: 'all 0.2s ease' }}
                    onClick={() => handleDeleteTab(tabs.findIndex(tab => tab.name === activeTab))}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = '#e53935';
                      e.currentTarget.style.transform = 'scale(1.15)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = '#ffebee';
                      e.currentTarget.style.transform = 'scale(1)';
                    }}
                    role="button"
                    tabIndex={0}
                  >🗑️</span>
                )}
                <button
                  className="create-tile-btn"
                  onClick={() => {
                    setShowTileModal(true);
                    setEditTileId(null);
                    setForm(f => ({
                      ...f,
                      name: '',
                      description: '',
                      link: '',
                      logo: '',
                      category: activeTab,
                      subcategory: '',
                      appType: 'web',
                      localPath: '',
                      paidSubscription: false,
                      paymentFrequency: null,
                      paymentAmount: null,
                      lastPaymentDate: null,
                      paymentTypeLast4: '',
                      accountLink: '',
                    }));
                  }}
                  title="Add web shortcut card"
                  style={{
                    background: '#757575',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '50%',
                    width: 32,
                    height: 32,
                    fontSize: 20,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 8px #0001',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#616161';
                    e.currentTarget.style.transform = 'scale(1.1)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(117, 117, 117, 0.4)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = '#757575';
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.boxShadow = '0 2px 8px #0001';
                  }}
                  aria-label="Add web shortcut card"
                >
                  +
                </button>
              </div>
            </div>
            )}

            {/* APP REPORT VIEW */}
            {activeTab === 'APP Report' && (
              <div style={{ marginTop: 24 }}>
                <div style={{ marginBottom: 16 }}>
                  <h2 style={{ margin: 0, color: '#1976d2' }}>Application Cost Report</h2>
                  {(() => {
                    const monthly = sortedReportTiles.reduce((sum, t) =>
                      sum + (t.paymentFrequency === 'Monthly' && typeof t.paymentAmount === 'number' ? t.paymentAmount : 0),
                    0);
                    const annual = sortedReportTiles.reduce((sum, t) =>
                      sum + (t.paymentFrequency === 'Annually' && typeof t.paymentAmount === 'number' ? t.paymentAmount : 0),
                    0);
                    return (
                      <div style={{ 
                        fontWeight: 600, 
                        fontSize: 14, 
                        marginTop: 6, 
                        display: 'flex', 
                        gap: 24, 
                        flexWrap: 'wrap'
                      }}>
                        <div>
                          Monthly Payment Sum: <span style={{ color: '#1976d2' }}>{formatCurrency(monthly) || '$0.00'}</span>
                        </div>
                        <div>
                          Annual Payment Sum: <span style={{ color: '#1976d2' }}>{formatCurrency(annual) || '$0.00'}</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
                <div style={{ 
                  background: '#fff', 
                  borderRadius: 8, 
                  boxShadow: '0 2px 8px #0001', 
                  padding: 16,
                  overflowX: 'auto'
                }}>
                  <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'minmax(150px, 2fr) minmax(200px, 2fr) minmax(100px, 1fr) minmax(100px, 1fr) minmax(120px, 1fr) minmax(120px, 1fr)', 
                    gap: 8, 
                    fontWeight: 700, 
                    borderBottom: '1px solid #eee', 
                    paddingBottom: 8, 
                    color: '#333' 
                  }}>
                    <div 
                      style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}
                      onClick={() => handleSort('name')}
                    >
                      Tile Name 
                      {sortColumn === 'name' && (
                        <span style={{ fontSize: 12 }}>{sortDirection === 'asc' ? '▲' : '▼'}</span>
                      )}
                    </div>
                    <div>Description</div>
                    <div style={{ textAlign: 'center' }}>Amount</div>
                    <div 
                      style={{ textAlign: 'center', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}
                      onClick={() => handleSort('frequency')}
                    >
                      Frequency
                      {sortColumn === 'frequency' && (
                        <span style={{ fontSize: 12 }}>{sortDirection === 'asc' ? '▲' : '▼'}</span>
                      )}
                    </div>
                    <div style={{ textAlign: 'center' }}>Payment Date</div>
                    <div 
                      style={{ textAlign: 'center', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}
                      onClick={() => handleSort('paymentType')}
                    >
                      Payment Type
                      {sortColumn === 'paymentType' && (
                        <span style={{ fontSize: 12 }}>{sortDirection === 'asc' ? '▲' : '▼'}</span>
                      )}
                    </div>
                  </div>
                  {sortedReportTiles.map((t, i) => (
                    <div key={`report-row-${i}`} style={{ 
                      display: 'grid', 
                      gridTemplateColumns: 'minmax(150px, 2fr) minmax(200px, 2fr) minmax(100px, 1fr) minmax(100px, 1fr) minmax(120px, 1fr) minmax(120px, 1fr)', 
                      gap: 8, 
                      padding: '10px 0', 
                      borderBottom: '1px solid #f2f2f2', 
                      color: '#333', 
                      fontSize: 14 
                    }}>
                      <div style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {t.accountLink ? (
                          <a href={t.accountLink} target="_blank" rel="noopener noreferrer" style={{ color: '#1976d2', textDecoration: 'underline' }}>
                            {t.name}
                          </a>
                        ) : (
                          t.name
                        )}
                      </div>
                      <div style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.description || ''}</div>
                      <div style={{ textAlign: 'center' }}>{formatCurrency(typeof t.paymentAmount === 'number' ? t.paymentAmount : null) || ''}</div>
                      <div style={{ textAlign: 'center' }}>{t.paymentFrequency || ''}</div>
                      <div style={{ textAlign: 'center' }}>{formatDate(t.lastPaymentDate) || ''}</div>
                      <div style={{ textAlign: 'center' }}>{t.paymentTypeLast4 ? `**** ${t.paymentTypeLast4}` : ''}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
              onDragOver={event => {
                const { over } = event;
                if (over && over.id && typeof over.id === 'string') {
                  if (tabs.some(tab => tab.name === over.id)) {
                    setDragOverTab(over.id);
                    setDragOverSubcategory(null);
                  } else if (over.id.toString().startsWith('subcategory-') || over.id === 'uncategorized') {
                    setDragOverTab(null);
                    setDragOverSubcategory(over.id.toString());
                  } else {
                    setDragOverTab(null);
                    setDragOverSubcategory(null);
                  }
                } else {
                  setDragOverTab(null);
                  setDragOverSubcategory(null);
                }
              }}
            >
              <SortableContext
                items={filteredTileIds}
                strategy={rectSortingStrategy}
              >
                {/* Display tiles grouped by subcategory */}
                {activeTab !== 'APP Report' && (
                  <div>
                    {/* Tiles grouped by subcategory */}
                    {tilesBySubcategory.map((group, groupIdx) => (
                      <DroppableSubcategorySection
                        key={group.name}
                        subcategoryName={group.name}
                        isDragOver={dragOverSubcategory === `subcategory-${group.name}`}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, paddingBottom: 8, borderBottom: '2px solid #e0e0e0' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <h2 style={{ color: '#ff6f00', fontSize: 20, fontWeight: 700, margin: 0 }}>
                              {group.name}
                            </h2>
                            <button
                              onClick={() => {
                                setShowTileModal(true);
                                setEditTileId(null);
                                setForm({
                                  name: '',
                                  description: '',
                                  link: '',
                                  category: activeTab,
                                  subcategory: group.name,
                                  logo: '',
                                  appType: 'web',
                                  localPath: '',
                                  paidSubscription: false,
                                  paymentFrequency: null,
                                  paymentAmount: null,
                                  lastPaymentDate: null,
                                  paymentTypeLast4: '',
                                  accountLink: '',
                                });
                              }}
                              title={`Add web shortcut card to ${group.name}`}
                              style={{
                                background: '#1976d2',
                                color: '#fff',
                                border: 'none',
                                borderRadius: '50%',
                                width: 24,
                                height: 24,
                                fontSize: 16,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                boxShadow: '0 2px 6px #0001',
                                cursor: 'pointer',
                                padding: 0,
                                transition: 'all 0.2s ease',
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = '#1565c0';
                                e.currentTarget.style.transform = 'scale(1.15)';
                                e.currentTarget.style.boxShadow = '0 4px 12px rgba(25, 118, 210, 0.4)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = '#1976d2';
                                e.currentTarget.style.transform = 'scale(1)';
                                e.currentTarget.style.boxShadow = '0 2px 6px #0001';
                              }}
                              aria-label={`Add web shortcut card to ${group.name}`}
                            >
                              <svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="9" y="4" width="2" height="12" rx="1" fill="#fff"/>
                                <rect x="4" y="9" width="12" height="2" rx="1" fill="#fff"/>
                              </svg>
                            </button>
                          </div>
                        </div>
                        {group.tiles.length > 0 ? (
                          <div className="tiles-grid tiles-grid-3">
                            {group.tiles.map((tile, idx) => (
                              <SortableTile tile={tile} idx={idx} key={tile.id} />
                            ))}
                          </div>
                        ) : (
                          <div style={{ padding: '32px', textAlign: 'center', color: '#999', fontSize: 14 }}>
                            Drop web shortcut cards here to add to {group.name}
                          </div>
                        )}
                      </DroppableSubcategorySection>
                    ))}
                    
                    {/* Tiles without subcategory - moved to bottom */}
                    {(tilesWithoutSubcategory.length > 0 || subcategories.length > 0) && (
                      <div style={{ 
                        marginTop: subcategories.length > 0 ? 48 : 0,
                        paddingTop: subcategories.length > 0 ? 32 : 0,
                        borderTop: subcategories.length > 0 ? '3px solid #e0e0e0' : 'none'
                      }}>
                        <DroppableSubcategorySection
                          subcategoryName=""
                          isDragOver={dragOverSubcategory === 'uncategorized'}
                        >
                          {subcategories.length > 0 && (
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, paddingBottom: 8, borderBottom: '2px solid #e0e0e0' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                <h2 style={{ color: '#999', fontSize: 20, fontWeight: 700, margin: 0, display: 'flex', alignItems: 'center', gap: 12 }}>
                                  <span>Uncategorized</span>
                                  <span style={{ fontSize: 14, fontWeight: 400, color: '#666' }}>(Drop here to remove subcategory)</span>
                                </h2>
                                <button
                                  onClick={() => {
                                    setShowTileModal(true);
                                    setEditTileId(null);
                                    setForm({
                                      name: '',
                                      description: '',
                                      link: '',
                                      category: activeTab,
                                      subcategory: '',
                                      logo: '',
                                      appType: 'web',
                                      localPath: '',
                                      paidSubscription: false,
                                      paymentFrequency: null,
                                      paymentAmount: null,
                                      lastPaymentDate: null,
                                      paymentTypeLast4: '',
                                      accountLink: '',
                                    });
                                  }}
                                  title="Add web shortcut card to Uncategorized"
                                  style={{
                                    background: '#1976d2',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: '50%',
                                    width: 24,
                                    height: 24,
                                    fontSize: 16,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    boxShadow: '0 2px 6px #0001',
                                    cursor: 'pointer',
                                    padding: 0,
                                    transition: 'all 0.2s ease',
                                  }}
                                  onMouseEnter={(e) => {
                                    e.currentTarget.style.background = '#1565c0';
                                    e.currentTarget.style.transform = 'scale(1.15)';
                                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(25, 118, 210, 0.4)';
                                  }}
                                  onMouseLeave={(e) => {
                                    e.currentTarget.style.background = '#1976d2';
                                    e.currentTarget.style.transform = 'scale(1)';
                                    e.currentTarget.style.boxShadow = '0 2px 6px #0001';
                                  }}
                                  aria-label="Add web shortcut card to Uncategorized"
                                >
                                  <svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="9" y="4" width="2" height="12" rx="1" fill="#fff"/>
                                    <rect x="4" y="9" width="12" height="2" rx="1" fill="#fff"/>
                                  </svg>
                                </button>
                              </div>
                            </div>
                          )}
                          {tilesWithoutSubcategory.length > 0 ? (
                            <div className="tiles-grid tiles-grid-3">
                              {tilesWithoutSubcategory.map((tile, idx) => (
                                <SortableTile tile={tile} idx={idx} key={tile.id} />
                              ))}
                            </div>
                          ) : subcategories.length > 0 && (
                            <div style={{ padding: '40px', textAlign: 'center', color: '#999', fontSize: 15, background: '#fafafa', borderRadius: 8, border: '2px dashed #ddd' }}>
                              Drop web shortcut cards here to remove their subcategory
                            </div>
                          )}
                        </DroppableSubcategorySection>
                      </div>
                    )}
                  </div>
                )}
              </SortableContext>
            </DndContext>

            {/* Tile Modal */}
            {showTileModal && (
              <Modal onClose={() => { setShowTileModal(false); setEditTileId(null); }}>
                <form onSubmit={handleFormSubmit} style={{ maxHeight: '70vh', overflowY: 'auto', paddingRight: 8 }}>
                  <h2>{editTileId !== null ? 'Edit Tile' : 'Create a New Tile'}</h2>
                  <label>
                    Name:<br />
                    <input
                      name="name"
                      value={form.name}
                      onChange={handleFormChange}
                      required
                      autoFocus
                    />
                  </label>
                  <label>
                    Description:<br />
                    <textarea
                      name="description"
                      value={form.description}
                      onChange={handleFormChange}
                      required
                    />
                  </label>
                  <label>
                    Application Type:<br />
                    <select
                      name="appType"
                      value={form.appType || 'web'}
                      onChange={handleFormChange}
                      style={{ width: '100%', padding: 10, marginTop: 4, marginBottom: 16 }}
                    >
                      <option value="web">Web Application (URL)</option>
                      <option value="protocol">Custom Protocol (cursor://, slack://, etc.)</option>
                      <option value="local">Local Application (reference only)</option>
                    </select>
                  </label>
                  {form.appType === 'web' && (
                    <label>
                      Web Link:<br />
                      <input
                        name="link"
                        value={form.link}
                        onChange={handleFormChange}
                        required
                        placeholder="https://example.com"
                      />
                    </label>
                  )}
                  {form.appType === 'protocol' && (
                    <label>
                      Protocol Handler:<br />
                      <input
                        name="link"
                        value={form.link}
                        onChange={handleFormChange}
                        required
                        placeholder="cursor:// or slack:// or vscode://"
                      />
                      <small style={{ display: 'block', color: '#666', marginTop: 4, fontSize: '0.85rem' }}>
                        Enter the custom protocol (e.g., cursor://, slack://, vscode://). The app must be installed and registered.
                      </small>
                    </label>
                  )}
                  {form.appType === 'local' && (
                    <>
                      <label>
                        Application Path:<br />
                        <input
                          name="localPath"
                          value={form.localPath || ''}
                          onChange={handleFormChange}
                          placeholder="C:\Program Files\App\app.exe"
                          style={{ width: '100%' }}
                        />
                        <small style={{ display: 'block', color: '#666', marginTop: 4, fontSize: '0.85rem' }}>
                          ⚠️ Web browsers cannot launch .exe files directly. This path is stored for reference only. You can copy it when clicking the tile.
                        </small>
                      </label>
                      <label>
                        Alternative Link (optional):<br />
                        <input
                          name="link"
                          value={form.link}
                          onChange={handleFormChange}
                          placeholder="https://example.com/download or file://path"
                        />
                        <small style={{ display: 'block', color: '#666', marginTop: 4, fontSize: '0.85rem' }}>
                          Optional: Provide a download page or file:// link as fallback
                        </small>
                      </label>
                    </>
                  )}
                  <label>
                    Logo URL:<br />
                    <input
                      name="logo"
                      value={form.logo}
                      onChange={handleFormChange}
                      placeholder="https://example.com/logo.png"
                    />
                  </label>
                  <label>
                    Category:<br />
                    <select
                      name="category"
                      value={form.category}
                      onChange={handleFormChange}
                    >
                      {tabs.map(tab => (
                        <option key={tab.name} value={tab.name}>{tab.name}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Subcategory (optional):<br />
                    <select
                      name="subcategory"
                      value={form.subcategory || ''}
                      onChange={handleFormChange}
                    >
                      <option value="">-- None --</option>
                      {(tabs.find(t => t.name === form.category)?.subcategories || []).map(sub => (
                        <option key={sub} value={sub}>{sub}</option>
                      ))}
                    </select>
                  </label>
                  <label style={{ display: 'block', marginTop: 16 }}>
                    Paid Subscription?&nbsp;
                    <span style={{ display: 'inline-flex', alignItems: 'center', marginLeft: 8 }}>
                      <span style={{ color: form.paidSubscription ? '#43a047' : '#888', fontWeight: 600, marginRight: 6 }}>No</span>
                      <input
                        type="checkbox"
                        checked={!!form.paidSubscription}
                        onChange={e => setForm(f => ({
                          ...f,
                          paidSubscription: e.target.checked,
                          paymentFrequency: e.target.checked ? (f.paymentFrequency || 'Monthly') : null,
                          paymentAmount: e.target.checked ? f.paymentAmount : null,
                          lastPaymentDate: e.target.checked ? f.lastPaymentDate : null,
                        }))}
                        style={{ width: 36, height: 20 }}
                      />
                      <span style={{ color: form.paidSubscription ? '#43a047' : '#888', fontWeight: 600, marginLeft: 6 }}>Yes</span>
                    </span>
                  </label>
                  {form.paidSubscription && (
                    <>
                      <label style={{ display: 'block', marginTop: 12 }}>
                        Payment Frequency:<br />
                        <select
                          name="paymentFrequency"
                          value={form.paymentFrequency || 'Monthly'}
                          onChange={e => setForm(f => ({ ...f, paymentFrequency: e.target.value as 'Monthly' | 'Annually' }))}
                          style={{ width: '100%', padding: 6, marginTop: 2 }}
                        >
                          <option value="Monthly">Monthly</option>
                          <option value="Annually">Annually</option>
                        </select>
                      </label>
                      <label style={{ display: 'block', marginTop: 12 }}>
                        Payment Amount:<br />
                        <input
                          type="number"
                          name="paymentAmount"
                          value={form.paymentAmount ?? ''}
                          onChange={e => setForm(f => ({ ...f, paymentAmount: e.target.value ? parseFloat(e.target.value) : null }))}
                          style={{ width: '100%', padding: 6, marginTop: 2 }}
                          min="0"
                          step="0.01"
                          placeholder="$0.00"
                        />
                      </label>
                      <label style={{ display: 'block', marginTop: 12 }}>
                        Payment Date:<br />
                        <input
                          type="date"
                          name="lastPaymentDate"
                          value={form.lastPaymentDate ?? ''}
                          onChange={e => setForm(f => ({ ...f, lastPaymentDate: e.target.value }))}
                          style={{ width: '100%', padding: 6, marginTop: 2 }}
                        />
                      </label>
                      <label style={{ display: 'block', marginTop: 12 }}>
                        Payment Type (Last 4 digits):<br />
                        <input
                          type="text"
                          name="paymentTypeLast4"
                          value={form.paymentTypeLast4 ?? ''}
                          onChange={e => {
                            const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 4);
                            setForm(f => ({ ...f, paymentTypeLast4: val }));
                          }}
                          style={{ width: '100%', padding: 6, marginTop: 2 }}
                          maxLength={4}
                          pattern="[0-9]{0,4}"
                          placeholder="1234"
                        />
                      </label>
                    </>
                  )}
                  <label style={{ display: 'block', marginTop: 12 }}>
                    Account Link:<br />
                    <input
                      type="url"
                      name="accountLink"
                      value={form.accountLink ?? ''}
                      onChange={e => setForm(f => ({ ...f, accountLink: e.target.value }))}
                      style={{ width: '100%', padding: 6, marginTop: 2 }}
                      placeholder="https://example.com/account"
                    />
                  </label>
                  <button type="submit">
                    {editTileId !== null ? 'Save Changes' : 'Create'}
                  </button>
                  <button type="button" onClick={() => { setShowTileModal(false); setEditTileId(null); }}>
                    Cancel
                  </button>
                </form>
              </Modal>
            )}

            {/* Tab Modal */}
            {showTabModal && (
              <Modal onClose={() => { setShowTabModal(false); setEditingTabIndex(null); setTabFormName(''); }}>
                <form onSubmit={handleTabFormSubmit}>
                  <h2>{tabModalMode === 'add' ? 'Add Tab' : 'Edit Tab'}</h2>
                  <label>
                    Tab Name:<br />
                    <input
                      value={tabFormName}
                      onChange={e => setTabFormName(e.target.value)}
                      required
                      autoFocus
                    />
                  </label>
                  <button type="submit">
                    {tabModalMode === 'add' ? 'Add Tab' : 'Save'}
                  </button>
                  <button type="button" onClick={() => { setShowTabModal(false); setEditingTabIndex(null); setTabFormName(''); }}>
                    Cancel
                  </button>
                </form>
              </Modal>
            )}

            {/* Delete Confirmation Modal */}
            {showDeleteModal && (
              <Modal onClose={() => { setShowDeleteModal(false); setTileToDeleteId(null); }}>
                <div style={{ textAlign: 'center', padding: '16px 0' }}>
                  <h2 style={{ marginBottom: 16 }}>Delete Tile?</h2>
                  <p style={{ marginBottom: 24 }}>Are you sure you want to delete this tile? This action cannot be undone.</p>
                  <button
                    style={{
                      background: '#e53935',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 6,
                      padding: '10px 20px',
                      fontSize: '1rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                      marginRight: 8,
                    }}
                    onClick={confirmDeleteTile}
                  >
                    Yes, Delete
                  </button>
                  <button
                    style={{
                      background: '#eee',
                      color: '#333',
                      border: 'none',
                      borderRadius: 6,
                      padding: '10px 20px',
                      fontSize: '1rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                    onClick={() => { setShowDeleteModal(false); setTileToDeleteId(null); }}
                  >
                    Cancel
                  </button>
                </div>
              </Modal>
            )}

            {/* Restore Confirmation Modal */}
            {showRestoreModal && (
              <Modal onClose={() => { setShowRestoreModal(false); setRestoreData(null); }}>
                <div style={{ textAlign: 'center', padding: '16px 0' }}>
                  <h2 style={{ marginBottom: 16 }}>Restore Data?</h2>
                  <p style={{ marginBottom: 24 }}>
                    Are you sure you want to restore this backup? This will overwrite your current tiles and tabs.
                  </p>
                  <button
                    style={{
                      background: '#43a047',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 6,
                      padding: '10px 20px',
                      fontSize: '1rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                      marginRight: 8,
                    }}
                    onClick={confirmRestore}
                  >
                    Yes, Restore
                  </button>
                  <button
                    style={{
                      background: '#eee',
                      color: '#333',
                      border: 'none',
                      borderRadius: 6,
                      padding: '10px 20px',
                      fontSize: '1rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                    onClick={() => { setShowRestoreModal(false); setRestoreData(null); }}
                  >
                    Cancel
                  </button>
                </div>
              </Modal>
            )}

            {/* Banner Title Edit Modal */}
            {showBannerTitleModal && (
              <Modal onClose={() => setShowBannerTitleModal(false)}>
                <form onSubmit={handleBannerTitleSubmit}>
                  <h2>Edit Banner Title</h2>
                  <label>
                    Banner Title:<br />
                    <input
                      value={bannerTitleForm}
                      onChange={e => setBannerTitleForm(e.target.value)}
                      required
                      autoFocus
                      placeholder="Enter banner title"
                    />
                  </label>
                  <button type="submit">
                    Save
                  </button>
                  <button type="button" onClick={() => setShowBannerTitleModal(false)}>
                    Cancel
                  </button>
                </form>
              </Modal>
            )}

            {/* Subcategory Management Modal */}
            {showSubcategoryModal && (
              <Modal onClose={() => { setShowSubcategoryModal(false); setEditingSubcategoryIndex(null); setSubcategoryForm(''); setSubcategoryModalMode('add'); }}>
                <div>
                  <h2>Manage Subcategories for {activeTab}</h2>
                  <div style={{ marginBottom: 24 }}>
                    <h3 style={{ fontSize: 16, marginBottom: 8, color: '#1976d2' }}>Current Subcategories:</h3>
                    {(tabs.find(t => t.name === activeTab)?.subcategories || []).length === 0 ? (
                      <p style={{ color: '#888', fontSize: 14 }}>No subcategories yet. Add one below!</p>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                        {(tabs.find(t => t.name === activeTab)?.subcategories || []).map((sub, idx) => (
                          <div
                            key={sub}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              padding: '8px 12px',
                              background: '#f4f6fb',
                              borderRadius: 6,
                              border: '1px solid #e0e0e0',
                            }}
                          >
                            <span style={{ flex: 1, fontWeight: 500 }}>{sub}</span>
                            <div style={{ display: 'flex', gap: 8 }}>
                              <span
                                className="edit-icon"
                                title="Edit Subcategory"
                                style={{ fontSize: 18, color: '#1976d2', cursor: 'pointer' }}
                                onClick={(e) => { e.stopPropagation(); openEditSubcategoryModal(idx); }}
                                role="button"
                                tabIndex={0}
                              >✏️</span>
                              <span
                                className="edit-icon"
                                title="Delete Subcategory"
                                style={{ fontSize: 18, color: '#e53935', cursor: 'pointer' }}
                                onClick={(e) => { e.stopPropagation(); handleDeleteSubcategory(idx); }}
                                role="button"
                                tabIndex={0}
                              >🗑️</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <form onSubmit={handleSubcategoryFormSubmit}>
                    <h3 style={{ fontSize: 16, marginBottom: 8, color: '#1976d2' }}>
                      {subcategoryModalMode === 'add' ? 'Add New Subcategory:' : 'Edit Subcategory:'}
                    </h3>
                    <label>
                      Subcategory Name:<br />
                      <input
                        value={subcategoryForm}
                        onChange={e => setSubcategoryForm(e.target.value)}
                        required
                        autoFocus={subcategoryModalMode === 'edit'}
                        placeholder="e.g., Personal, Business"
                      />
                    </label>
                    <button type="submit">
                      {subcategoryModalMode === 'add' ? 'Add Subcategory' : 'Save Changes'}
                    </button>
                    <button type="button" onClick={() => { 
                      setShowSubcategoryModal(false); 
                      setEditingSubcategoryIndex(null); 
                      setSubcategoryForm('');
                      setSubcategoryModalMode('add');
                    }}>
                      {subcategoryModalMode === 'add' ? 'Close' : 'Cancel'}
                    </button>
                  </form>
                </div>
              </Modal>
            )}
          </>
        )}
        {mainMenu === 'finance' && <FinanceManagementPage />}
        {mainMenu === 'files' && (
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: 32 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 32 }}>
              <div>
                <h1 style={{ margin: 0 }}>Files</h1>
              </div>
              <button
                onClick={() => fileInputRef.current && fileInputRef.current.click()}
                style={{
                  background: '#f4f6fb',
                  color: '#1976d2',
                  border: '2px solid #1976d2',
                  borderRadius: '50%',
                  width: 36,
                  height: 36,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 2px 8px #0001',
                  cursor: 'pointer',
                  padding: 0
                }}
                title="Pick Folder"
                aria-label="Pick Folder"
              >
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="9" y="4" width="2" height="12" rx="1" fill="#1976d2"/>
                  <rect x="4" y="9" width="12" height="2" rx="1" fill="#1976d2"/>
                </svg>
              </button>
              <input
                type="file"
                ref={fileInputRef}
                style={{ display: 'none' }}
                // @ts-ignore
                webkitdirectory="true"
                multiple
                onChange={handleFilesPicked}
              />
            </div>
            <div style={{ marginTop: 32 }}>
              {pickedFolders.length === 0 ? (
                <div style={{ color: '#888' }}>[No folders selected]</div>
              ) : (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
                  {pickedFolders.map((folder, idx) => (
                    <div key={folder.path + idx} style={{ border: '1px solid #eee', borderRadius: 8, background: '#fafbfc', minHeight: 120, display: 'flex', flexDirection: 'column', justifyContent: 'flex-start' }}>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          cursor: 'pointer',
                          padding: '14px 20px',
                          fontWeight: 700,
                          fontSize: 18,
                          color: '#1976d2',
                          borderBottom: folder.expanded ? '1px solid #e3e3e3' : 'none',
                          userSelect: 'none',
                        }}
                        onClick={() => toggleFolder(idx)}
                      >
                        <span style={{ marginRight: 12, fontSize: 20 }}>{folder.expanded ? '▼' : '▶'}</span>
                        <span style={{ flex: 1 }}>{folder.name}</span>
                        {folder.needsRepick && (
                          <>
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                repickRefs.current[idx]?.click();
                              }}
                              style={{
                                marginLeft: 8,
                                background: '#fff3e0',
                                color: '#e65100',
                                border: '1px solid #ffb300',
                                borderRadius: 6,
                                padding: '4px 12px',
                                fontSize: 14,
                                fontWeight: 600,
                                cursor: 'pointer',
                              }}
                            >
                              Re-pick
                            </button>
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                deleteFolder(idx);
                              }}
                              style={{
                                marginLeft: 8,
                                background: 'none',
                                border: 'none',
                                cursor: 'pointer',
                                color: '#e53935',
                                fontSize: 20,
                                display: 'flex',
                                alignItems: 'center',
                              }}
                              title="Delete Folder"
                              aria-label="Delete Folder"
                            >
                              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="6.5" y="8" width="1.5" height="6" rx="0.75" fill="#e53935"/>
                                <rect x="12" y="8" width="1.5" height="6" rx="0.75" fill="#e53935"/>
                                <rect x="9.25" y="8" width="1.5" height="6" rx="0.75" fill="#e53935"/>
                                <rect x="4" y="5" width="12" height="2" rx="1" fill="#e53935"/>
                                <rect x="7" y="3" width="6" height="2" rx="1" fill="#e53935"/>
                                <rect x="3" y="7" width="14" height="10" rx="2" stroke="#e53935" strokeWidth="1.5" fill="none"/>
                              </svg>
                            </button>
                          </>
                        )}
                        <input
                          type="file"
                          ref={el => (repickRefs.current[idx] = el)}
                          style={{ display: 'none' }}
                          // @ts-ignore
                          webkitdirectory="true"
                          multiple
                          onChange={e => handleFilesPicked(e, idx)}
                        />
                      </div>
                      <div style={{ padding: '0 20px 10px 52px', color: '#888', fontSize: 14 }}>{folder.path || '[Root]'}</div>
                      {folder.expanded && (
                        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                          {(folder.files.length ? folder.files : folder.fileNames)
                            .filter((file: any) => {
                              const fileName = typeof file === 'string' ? file : file.webkitRelativePath?.replace(folder.path + '/', '') || file.name;
                              return fileName.toLowerCase().endsWith('.pptx') || fileName.toLowerCase().endsWith('.pptm');
                            })
                            .map((file: any, i: number) => {
                              const fileName = typeof file === 'string' ? file : file.webkitRelativePath?.replace(folder.path + '/', '') || file.name;
                              const url = typeof file === 'string' ? undefined : URL.createObjectURL(file);
                              return (
                                <li key={fileName + i} style={{ padding: '6px 0', borderBottom: '1px solid #eee', fontSize: 16, display: 'flex', alignItems: 'center' }}>
                                  {getFileIcon(fileName)}
                                  {url ? (
                                    <a
                                      href={url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      style={{ color: '#1976d2', textDecoration: 'underline', wordBreak: 'break-all' }}
                                      onClick={e => {
                                        setTimeout(() => URL.revokeObjectURL(url), 10000);
                                      }}
                                    >
                                      {fileName}
                                    </a>
                                  ) : (
                                    <span style={{ color: '#888', wordBreak: 'break-all' }}>{fileName}</span>
                                  )}
                                </li>
                              );
                            })}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;