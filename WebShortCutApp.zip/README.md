**Installation**

Step 1. Create a folder on your PC for your Web-Shortcut APP

Step 2: Copy the zip file to this folder (including Start-App.bat) to PC

Step 3: Install Nodejs from https://nodejs.org (from your download folder, just dbl click the install file and let it run)



**After Installation**

Step 1: Double-click Start-App.bat, (Auto-open in Chrome at localhost:5173)

Step 2: (Optional), Right click the Start-App.bat and create a shortcut, move it to your desktop





